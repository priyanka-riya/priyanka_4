# Currency-Recognition-Using-Deep-Learning-CNN-
This project implements Currency Recognition using Convolutional Neural Networks (CNNs) to classify different types of currency notes. The model is trained using TensorFlow and Keras, with real-time image recognition capabilities. Advanced techniques like Batch Normalization, Dropout, and Learning Rate Scheduling enhance model performance.
