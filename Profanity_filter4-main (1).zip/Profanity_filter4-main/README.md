# Profanity_filter4
An AI-powered profanity filter that detects and censors bad words in user comments.   Supports transliterated Tamil, Malayalam, Telugu, Kannada, and Hindi words typed in English.   Built with Python and Streamlit for a simple, interactive frontend.  
