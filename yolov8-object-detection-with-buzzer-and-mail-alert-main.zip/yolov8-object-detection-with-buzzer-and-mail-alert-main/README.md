# yolov8-object-detection-with-buzzer-and-mail-alert
This project implements YOLOv8 for real-time object detection, integrating Google Text-to-Speech (GTTS) for voice alerts and a buzzer system to notify users when specific objects are detected. Additionally, it sends email notifications with detected object details and images.
